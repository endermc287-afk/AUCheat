# AUTest — Build & Install Guide

## Requirements
- Android Studio Hedgehog (2023.1) or newer
- Android SDK 34
- Kotlin 1.9.x
- Target device: Android 8.0+ (API 26+), ARM64

---

## 1. Open in Android Studio

1. Clone / extract the project folder.
2. Open **Android Studio → File → Open** → select `AUTestProject/`.
3. Wait for Gradle sync to finish (requires internet for dependencies).

---

## 2. Build

### Debug APK (recommended for testing)
```
Build → Build Bundle(s) / APK(s) → Build APK(s)
```
Output: `app/build/outputs/apk/debug/app-debug.apk`

### Release APK
1. **Build → Generate Signed Bundle / APK → APK**
2. Create a new keystore or use an existing one.
3. Select `release` build variant.
4. Output: `app/build/outputs/apk/release/app-release.apk`

### Termux (on-device build)
```bash
# Install dependencies
pkg install git openjdk-17 gradle

# Clone and build
cd AUTestProject
./gradlew assembleDebug

# APK location
ls app/build/outputs/apk/debug/
```

---

## 3. Install

### Via ADB
```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

### Via File Manager
Transfer the APK to the device and tap to install.  
Enable **Install from unknown sources** in Settings → Security if prompted.

---

## 4. First Launch

1. Open **AUTest** from the launcher.
2. Tap **LAUNCH GAME**.
3. If prompted, grant **Display Over Other Apps** permission and return.
4. The screen clears — the full-screen game is now active.

---

## 5. Controls

| Control | Action |
|---|---|
| Left side drag | Virtual joystick — move player |
| **KILL** button | Kill nearest crewmate (Impostor only) |
| **TASK** button | Complete nearest assigned task (Crewmate only) |
| **VENT** button | Enter/exit vent (Impostor only) |
| **MEET** button | Call emergency meeting |
| **START** button | Begin a new round |
| **⚙** floating icon | Open / close mod menu |

---

## 6. Mod Menu

Tap the **⚙** icon (top-right, draggable) to open the panel.

### Categories
| Tab | Modules |
|---|---|
| **Player** | Speed Hack, Infinite Vision, Custom Scale, Freecam |
| **Impostor** | Always Impostor, No Cooldown |
| **Detector** | Impostor Detector (live role table) |
| **ESP** | Player ESP, Impostor ESP |
| **Visuals** | Custom Player Scale |
| **Game** | (future expansion) |
| **Config** | (future expansion) |

### Module Details

#### Always Impostor
Toggle ON before or during a round. Immediately forces the local player's role to Impostor.  
A bot Impostor is demoted to Crewmate to keep the total Impostor count correct.

#### Impostor Detector
Toggle ON → switch to the **Detector** tab.  
Displays all players with their actual roles highlighted RED (Impostor) / GREEN (Crewmate).  
Updates every game tick after roles are assigned.

#### Impostor ESP
Draws red bounding boxes around all Impostor players on the game view, bypassing vision radius.

#### Player ESP
Draws bounding boxes + name + role + distance for every player, regardless of vision.

#### Speed Hack
Toggle ON → adjust the **Speed** slider (1.0× – 6.0×).  
Applies immediately; persists across rounds.

#### No Cooldown
Toggle ON → kill cooldown is zeroed every tick.  
KILL button always shows as ready (red).

#### Freecam
Toggle ON → camera detaches from local player.  
Drag the game view to pan; pinch to zoom (0.25× – 2.0×).

#### Infinite Vision
Toggle ON → removes vision radius limit; all players visible at all times.

---

## 7. Settings Persistence

All module toggles and the Speed multiplier are saved automatically to  
`/data/data/com.tris.autest/shared_prefs/autest_prefs.xml` on the device.  
They restore on next launch.

---

## 8. Stopping

- Tap **⚙ → STOP** in the menu, or
- Pull down the notification shade and tap **STOP**, or
- Return to the AUTest launcher → tap **STOP**.

---

## 9. Troubleshooting

| Issue | Fix |
|---|---|
| Black screen after launch | Grant overlay permission; check logcat for `FloatingMenuService` |
| ⚙ icon not visible | Scroll / drag — it starts top-right |
| Gradle sync fails | Check internet; invalidate caches (File → Invalidate Caches) |
| `TYPE_APPLICATION_OVERLAY` crash | Requires Android 8.0+; check minSdk |
| FPS counter shows 0 | Surface not ready yet; wait 1–2 seconds |

---

## Package Info
```
Package:    com.tris.autest
Debug pkg:  com.tris.autest.debug
Min SDK:    26 (Android 8.0)
Target SDK: 34 (Android 14)
ABI:        arm64-v8a (all ABIs via Gradle default)
```
