package com.tris.autest.game

import android.graphics.PointF

/** The phase the game is currently in. */
enum class GamePhase {
    LOBBY,          // Waiting to start
    PLAYING,        // Active gameplay
    DISCUSSION,     // Emergency meeting / body report phase
    VOTING,         // Players voting (simplified: auto-vote in test)
    ROUND_END,      // Win/loss screen before next round
    ENDED           // Session ended by user
}

/** End condition result. */
enum class WinCondition { NONE, CREWMATES_WIN, IMPOSTORS_WIN }

/**
 * The authoritative game state.
 * [GameEngine] owns and mutates this; [GameRenderer] reads it every frame.
 * Access from any thread must be synchronised on [lock].
 */
class GameState {

    val lock = Any()

    // ── Players ────────────────────────────────────────────────────────────
    val players: MutableList<Player> = mutableListOf()
    val localPlayer: Player? get() = players.firstOrNull { it.isLocal }
    val alivePlayers: List<Player> get() = players.filter { it.isAlive }
    val aliveImpostors: List<Player> get() = alivePlayers.filter { it.isImpostor }
    val aliveCrewmates: List<Player> get() = alivePlayers.filter { !it.isImpostor }

    // ── Phase ──────────────────────────────────────────────────────────────
    var phase: GamePhase = GamePhase.LOBBY
    var phaseTimer: Long = 0L          // ms remaining in current timed phase

    // ── Round ──────────────────────────────────────────────────────────────
    var roundNumber: Int = 0
    var winCondition: WinCondition = WinCondition.NONE

    // ── Dead bodies (position of death, used for Report) ──────────────────
    data class DeadBody(val playerId: Int, val position: PointF)
    val deadBodies: MutableList<DeadBody> = mutableListOf()

    // ── Task progress ──────────────────────────────────────────────────────
    val totalTasks: Int get() = players
        .filter { !it.isImpostor }
        .sumOf { it.totalTasks }
    val completedTasks: Int get() = players
        .filter { !it.isImpostor }
        .sumOf { it.tasksCompleted }
    val taskBarProgress: Float get() = if (totalTasks == 0) 0f
                                       else completedTasks.toFloat() / totalTasks

    // ── Camera (Freecam module writes here) ───────────────────────────────
    var cameraTarget: PointF = PointF(0f, 0f)
    var cameraZoom: Float = 1.0f

    // ── Notifications queue (read and cleared by renderer/UI) ─────────────
    data class Notification(val message: String, val color: Int, val expiresAt: Long)
    val notifications: MutableList<Notification> = mutableListOf()

    fun postNotification(msg: String, color: Int, durationMs: Long = 2500L) {
        synchronized(lock) {
            notifications.add(
                Notification(msg, color, System.currentTimeMillis() + durationMs)
            )
            // Keep at most 5
            if (notifications.size > 5) notifications.removeAt(0)
        }
    }

    fun pruneNotifications() {
        synchronized(lock) {
            val now = System.currentTimeMillis()
            notifications.removeAll { it.expiresAt < now }
        }
    }

    // ── Reset for a new session ────────────────────────────────────────────
    fun reset() {
        synchronized(lock) {
            players.clear()
            deadBodies.clear()
            notifications.clear()
            phase = GamePhase.LOBBY
            phaseTimer = 0L
            roundNumber = 0
            winCondition = WinCondition.NONE
            cameraTarget.set(0f, 0f)
            cameraZoom = 1.0f
        }
    }
}
