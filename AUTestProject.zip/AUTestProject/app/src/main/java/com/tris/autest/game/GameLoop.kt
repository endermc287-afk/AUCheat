package com.tris.autest.game

import android.util.Log
import com.tris.autest.utils.FPSCounter

/**
 * Fixed-timestep game loop running on its own thread.
 *
 * Logic is ticked at [TARGET_TPS] per second with a fixed dt.
 * The render callback is called as fast as the CPU allows (uncapped),
 * but the renderer should use its own SurfaceHolder lock timing.
 *
 * Usage:
 *   val loop = GameLoop(engine) { renderCallback() }
 *   loop.start()
 *   ...
 *   loop.stop()
 */
class GameLoop(
    private val engine: GameEngine,
    private val onRender: () -> Unit
) {
    private val TAG = "GameLoop"

    companion object {
        const val TARGET_TPS = 60               // logic ticks per second
        const val FIXED_DT   = 1f / TARGET_TPS  // seconds per tick
        private const val NS_PER_TICK = 1_000_000_000L / TARGET_TPS
        private const val MAX_SKIP   = 5        // max logic ticks per render frame
    }

    val fpsCounter = FPSCounter()

    @Volatile private var running = false
    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread(::loop, "GameLoop").also {
            it.priority = Thread.MAX_PRIORITY
            it.start()
        }
    }

    fun stop() {
        running = false
        thread?.interrupt()
        thread?.join(500)
        thread = null
    }

    private fun loop() {
        var lastTime = System.nanoTime()
        var lag      = 0L

        while (running) {
            val now   = System.nanoTime()
            val elapsed = now - lastTime
            lastTime  = now
            lag      += elapsed

            // --- Logic ticks (catch up if behind) ---
            var ticks = 0
            while (lag >= NS_PER_TICK && ticks < MAX_SKIP) {
                try {
                    engine.tick(FIXED_DT)
                } catch (e: Exception) {
                    Log.e(TAG, "Engine tick error", e)
                }
                lag  -= NS_PER_TICK
                ticks++
            }

            // --- Render ---
            try {
                onRender()
                fpsCounter.frame()
            } catch (e: Exception) {
                Log.e(TAG, "Render error", e)
            }

            // --- Sleep to avoid busy-spin when ahead ---
            val remaining = NS_PER_TICK - lag
            if (remaining > 1_000_000L) {
                try {
                    Thread.sleep(remaining / 1_000_000L)
                } catch (e: InterruptedException) {
                    Thread.currentThread().interrupt()
                    break
                }
            }
        }
    }
}
