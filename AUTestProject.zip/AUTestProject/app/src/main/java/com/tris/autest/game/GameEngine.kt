package com.tris.autest.game

import android.graphics.Color
import android.graphics.PointF
import com.tris.autest.modules.ModuleManager
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Core game logic engine.
 * Tick-driven: [tick] is called every frame by [GameLoop] with the delta time in seconds.
 *
 * All state lives in [GameState]; this class mutates it.
 */
class GameEngine(
    private val state: GameState,
    private val moduleManager: ModuleManager
) {

    // ── Player colours ─────────────────────────────────────────────────────
    private val playerColors = intArrayOf(
        Color.parseColor("#E8120C"), // Red
        Color.parseColor("#132FD2"), // Blue
        Color.parseColor("#117F2D"), // Green
        Color.parseColor("#ED53B9"), // Pink
        Color.parseColor("#EF7D0D"), // Orange
        Color.parseColor("#F5F557"), // Yellow
        Color.parseColor("#3F474E"), // Black
        Color.parseColor("#D6E0F0"), // White
        Color.parseColor("#6B2FBB"), // Purple
        Color.parseColor("#71491E"), // Brown
    )

    private val botNames = listOf(
        "Alpha","Beta","Gamma","Delta","Epsilon",
        "Zeta","Eta","Theta","Iota"
    )

    // ── Joystick input (set by GameRenderer touch handler) ─────────────────
    var inputDx: Float = 0f
    var inputDy: Float = 0f

    // ── Init ───────────────────────────────────────────────────────────────
    fun initSession() {
        synchronized(state.lock) {
            state.reset()
            GameConfig.reset()

            // Local player
            val local = Player(
                id = 0,
                name = "YOU",
                playerColor = playerColors[0],
                isLocal = true,
                position = PointF(spawnPoint(0))
            )
            state.players.add(local)

            // Bots
            for (i in 1..GameConfig.BOT_COUNT) {
                state.players.add(
                    Player(
                        id = i,
                        name = botNames[i - 1],
                        playerColor = playerColors[i % playerColors.size],
                        position = PointF(spawnPoint(i))
                    )
                )
            }

            // Reset task map
            MapData.taskNodes.forEach { it.isComplete = false; it.assignedTo = -1 }
            assignTasks()

            state.phase = GamePhase.LOBBY
        }
    }

    /** Start the actual round from lobby. */
    fun startRound() {
        synchronized(state.lock) {
            state.roundNumber++
            state.winCondition = WinCondition.NONE
            state.deadBodies.clear()

            // Revive everyone for a fresh round
            state.players.forEach { p ->
                p.isAlive = true
                p.tasksCompleted = 0
                p.isInVent = false
                p.killCooldownMs = GameConfig.activeKillCooldownMs
            }

            // Reset tasks
            MapData.taskNodes.forEach { it.isComplete = false; it.assignedTo = -1 }
            assignTasks()

            // Assign roles
            assignRoles()

            state.phase = GamePhase.PLAYING
            state.postNotification("Round ${state.roundNumber} started!", Color.WHITE)
        }
    }

    // ── Main tick ──────────────────────────────────────────────────────────
    fun tick(dt: Float) {
        synchronized(state.lock) {
            if (state.phase != GamePhase.PLAYING) return
            state.pruneNotifications()

            // Apply active modules
            moduleManager.onGameTick(state, dt)

            // Update local player movement
            updateLocalPlayer(dt)

            // Update bots
            state.players.filter { !it.isLocal && it.isAlive }.forEach { updateBot(it, dt) }

            // Tick kill cooldowns
            state.players.filter { it.isImpostor && it.isAlive }.forEach { imp ->
                if (!GameConfig.noKillCooldown && imp.killCooldownMs > 0L) {
                    imp.killCooldownMs = maxOf(0L, imp.killCooldownMs - (dt * 1000f).toLong())
                } else if (GameConfig.noKillCooldown) {
                    imp.killCooldownMs = 0L
                }
            }

            // Freecam: camera follows local player unless overridden
            if (!GameConfig.freecamEnabled) {
                state.localPlayer?.let { lp ->
                    state.cameraTarget.set(lp.position)
                }
            }

            // Win condition check
            checkWinConditions()
        }
    }

    // ── Movement ───────────────────────────────────────────────────────────
    private fun updateLocalPlayer(dt: Float) {
        val lp = state.localPlayer ?: return
        if (!lp.isAlive) return

        val speed = GameConfig.activeSpeed
        val dx = inputDx * speed * dt
        val dy = inputDy * speed * dt

        val nx = lp.position.x + dx
        val ny = lp.position.y + dy

        // Soft wall: only move if walkable, otherwise try axis-separately
        when {
            isWalkable(nx, ny)                           -> lp.position.set(nx, ny)
            isWalkable(nx, lp.position.y)                -> lp.position.set(nx, lp.position.y)
            isWalkable(lp.position.x, ny)                -> lp.position.set(lp.position.x, ny)
        }
    }

    // ── Bot AI ─────────────────────────────────────────────────────────────
    private fun updateBot(bot: Player, dt: Float) {
        val now = System.currentTimeMillis()

        // Pick a new wander target when timer expires or we arrived
        if (bot.botTarget == null || bot.botStateTimer < now) {
            if (bot.isImpostor) {
                // Impostors: pursue nearest crewmate if close enough, else wander
                val target = state.aliveCrewmates
                    .filter { it.id != bot.id }
                    .minByOrNull { bot.distanceTo(it) }
                if (target != null && bot.distanceTo(target) < 400f) {
                    bot.botTarget = PointF(target.position)
                    // Attempt kill if in range and cooldown ready
                    if (bot.distanceTo(target) < GameConfig.BOT_KILL_RANGE
                        && bot.killCooldownMs == 0L) {
                        killPlayer(bot, target)
                        bot.killCooldownMs = GameConfig.activeKillCooldownMs
                    }
                } else {
                    bot.botTarget = randomWalkablePoint()
                }
            } else {
                // Crewmates: walk toward an incomplete assigned task, else wander
                val task = MapData.taskNodes.firstOrNull {
                    it.assignedTo == bot.id && !it.isComplete
                }
                bot.botTarget = task?.position ?: randomWalkablePoint()

                // Complete task if arrived
                if (task != null && bot.distanceTo(task.position) < GameConfig.TASK_INTERACT_RANGE) {
                    task.isComplete = true
                    bot.tasksCompleted++
                }
            }
            bot.botStateTimer = now + Random.nextLong(
                GameConfig.BOT_WANDER_INTERVAL_MS / 2,
                GameConfig.BOT_WANDER_INTERVAL_MS
            )
        }

        // Move toward target
        bot.botTarget?.let { target ->
            val dx = target.x - bot.position.x
            val dy = target.y - bot.position.y
            val dist = sqrt(dx * dx + dy * dy)
            if (dist > 4f) {
                val spd = GameConfig.BOT_SPEED * dt
                val move = min(spd, dist)
                val nx = bot.position.x + (dx / dist) * move
                val ny = bot.position.y + (dy / dist) * move
                when {
                    isWalkable(nx, ny)              -> bot.position.set(nx, ny)
                    isWalkable(nx, bot.position.y)  -> bot.position.set(nx, bot.position.y)
                    isWalkable(bot.position.x, ny)  -> bot.position.set(bot.position.x, ny)
                    else                            -> bot.botTarget = randomWalkablePoint()
                }
            } else {
                bot.botTarget = null
            }
        }
    }

    // ── Kill ───────────────────────────────────────────────────────────────
    /**
     * Local player attempts to kill the nearest crewmate in range.
     * Returns true if a kill happened.
     */
    fun attemptKill(): Boolean {
        val lp = state.localPlayer ?: return false
        if (!lp.isImpostor || !lp.isAlive) return false
        if (lp.killCooldownMs > 0L && !GameConfig.noKillCooldown) return false

        val target = state.aliveCrewmates
            .filter { !it.isLocal }
            .minByOrNull { lp.distanceTo(it) } ?: return false

        if (lp.distanceTo(target) > GameConfig.DEFAULT_KILL_RANGE) return false

        killPlayer(lp, target)
        lp.killCooldownMs = if (GameConfig.noKillCooldown) 0L else GameConfig.activeKillCooldownMs
        return true
    }

    private fun killPlayer(killer: Player, victim: Player) {
        victim.die()
        state.deadBodies.add(GameState.DeadBody(victim.id, PointF(victim.position)))
        state.postNotification("${killer.name} killed ${victim.name}!", Color.RED)
    }

    // ── Task interaction ───────────────────────────────────────────────────
    fun attemptTask(): Boolean {
        val lp = state.localPlayer ?: return false
        if (!lp.isAlive || lp.isImpostor) return false
        val node = MapData.nearestTaskNode(lp.position.x, lp.position.y, GameConfig.TASK_INTERACT_RANGE)
            ?.takeIf { it.assignedTo == lp.id } ?: return false
        node.isComplete = true
        lp.tasksCompleted++
        state.postNotification("Task completed! (${lp.tasksCompleted}/${lp.totalTasks})", Color.GREEN)
        return true
    }

    // ── Vent ───────────────────────────────────────────────────────────────
    fun attemptVent(): Boolean {
        val lp = state.localPlayer ?: return false
        if (!lp.isImpostor || !lp.isAlive) return false

        return if (lp.isInVent) {
            // Exit vent
            lp.isInVent = false
            state.postNotification("Exited vent", Color.MAGENTA)
            true
        } else {
            val vent = MapData.nearestVent(lp.position.x, lp.position.y, GameConfig.TASK_INTERACT_RANGE)
                ?: return false
            lp.isInVent = true
            // Teleport to a random linked vent
            val linked = vent.linkedVentIds.mapNotNull { id -> MapData.vents.getOrNull(id) }
            linked.randomOrNull()?.let { dest ->
                lp.position.set(dest.position)
            }
            state.postNotification("Vented!", Color.MAGENTA)
            true
        }
    }

    // ── Emergency / Report ─────────────────────────────────────────────────
    fun callEmergencyMeeting() {
        if (state.phase != GamePhase.PLAYING) return
        synchronized(state.lock) {
            state.phase = GamePhase.DISCUSSION
            state.phaseTimer = 30_000L   // 30s discussion
            state.postNotification("Emergency Meeting called!", Color.YELLOW)
        }
    }

    // ── Roles ──────────────────────────────────────────────────────────────
    private fun assignRoles() {
        val count = GameConfig.DEFAULT_IMPOSTOR_COUNT.coerceAtMost(state.players.size / 3)
        val shuffled = state.players.shuffled()

        shuffled.forEachIndexed { i, p ->
            p.role = if (i < count) Role.IMPOSTOR else Role.CREWMATE
        }

        // AlwaysImpostor override
        if (GameConfig.alwaysImpostorEnabled) {
            state.localPlayer?.let { lp ->
                // Demote one random impostor to crewmate to keep count correct
                if (lp.role != Role.IMPOSTOR) {
                    state.players.firstOrNull { it.isImpostor && !it.isLocal }
                        ?.role = Role.CREWMATE
                    lp.role = Role.IMPOSTOR
                }
            }
        }

        val impCount = state.players.count { it.isImpostor }
        state.postNotification(
            "Roles assigned — $impCount Impostor(s)",
            Color.parseColor("#CC44FF")
        )
    }

    // ── Tasks ───────────────────────────────────────────────────────────────
    private fun assignTasks() {
        val crewmates = state.players.filter { !it.isImpostor }
        val shuffled = MapData.taskNodes.shuffled().toMutableList()

        crewmates.forEach { p ->
            p.totalTasks = GameConfig.TASKS_PER_CREWMATE
            var assigned = 0
            val it = shuffled.iterator()
            while (it.hasNext() && assigned < GameConfig.TASKS_PER_CREWMATE) {
                val node = it.next()
                if (node.assignedTo == -1) {
                    node.assignedTo = p.id
                    assigned++
                    it.remove()
                }
            }
        }
    }

    // ── Win conditions ─────────────────────────────────────────────────────
    private fun checkWinConditions() {
        if (state.phase != GamePhase.PLAYING) return

        val aliveCrew = state.aliveCrewmates.size
        val aliveImp  = state.aliveImpostors.size

        when {
            aliveImp == 0 -> endRound(WinCondition.CREWMATES_WIN)
            aliveImp >= aliveCrew -> endRound(WinCondition.IMPOSTORS_WIN)
            state.taskBarProgress >= 1f -> endRound(WinCondition.CREWMATES_WIN)
        }
    }

    private fun endRound(result: WinCondition) {
        state.winCondition = result
        state.phase = GamePhase.ROUND_END
        val msg = when (result) {
            WinCondition.CREWMATES_WIN -> "Crewmates win! 🎉"
            WinCondition.IMPOSTORS_WIN -> "Impostors win! 💀"
            else -> ""
        }
        state.postNotification(msg, Color.WHITE, 5000L)
    }

    // ── Helpers ─────────────────────────────────────────────────────────────
    private fun spawnPoint(index: Int): PointF {
        return MapData.spawnPoints.getOrElse(index) { PointF(300f, 240f) }.let {
            PointF(it.x + Random.nextFloat() * 20f - 10f,
                   it.y + Random.nextFloat() * 20f - 10f)
        }
    }

    private fun randomWalkablePoint(): PointF {
        val room = MapData.rooms.random()
        return PointF(
            Random.nextFloat() * (room.bounds.width() - 20f) + room.bounds.left + 10f,
            Random.nextFloat() * (room.bounds.height() - 20f) + room.bounds.top + 10f
        )
    }

    private fun isWalkable(x: Float, y: Float): Boolean {
        // Always allow within map bounds for simplicity; rooms are open corridors
        return x >= 0f && x <= GameConfig.MAP_WIDTH &&
               y >= 0f && y <= GameConfig.MAP_HEIGHT
    }
}
