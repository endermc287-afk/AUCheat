package com.tris.autest

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.tris.autest.databinding.ActivityMainBinding
import com.tris.autest.service.FloatingMenuService

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    companion object {
        const val REQ_OVERLAY = 1001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Keep screen on while launcher is visible
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnLaunch.setOnClickListener { checkAndLaunch() }
        binding.btnStop.setOnClickListener   { stopOverlay() }

        updateButtonState()
    }

    override fun onResume() {
        super.onResume()
        updateButtonState()
        // If permission was just granted via the overlay screen, auto-launch
        if (Settings.canDrawOverlays(this)) {
            if (!isServiceRunning()) launchService()
        }
    }

    private fun checkAndLaunch() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(this, OverlayPermissionActivity::class.java)
            )
        } else {
            launchService()
        }
    }

    private fun launchService() {
        startForegroundService(
            Intent(this, FloatingMenuService::class.java)
        )
        Toast.makeText(this, "AUTest launched!", Toast.LENGTH_SHORT).show()
        // Go home so the game view is fully visible
        startActivity(
            Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
        )
    }

    private fun stopOverlay() {
        stopService(Intent(this, FloatingMenuService::class.java))
        updateButtonState()
        Toast.makeText(this, "AUTest stopped.", Toast.LENGTH_SHORT).show()
    }

    private fun isServiceRunning(): Boolean {
        val manager = getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager
        @Suppress("DEPRECATION")
        return manager.getRunningServices(Int.MAX_VALUE)
            .any { it.service.className == FloatingMenuService::class.java.name }
    }

    private fun updateButtonState() {
        val running = isServiceRunning()
        binding.btnLaunch.isEnabled = !running
        binding.btnStop.isEnabled   = running
        binding.tvStatus.text       = if (running) "● Running" else "● Stopped"
        binding.tvStatus.setTextColor(
            if (running) android.graphics.Color.parseColor("#44FF88")
            else android.graphics.Color.parseColor("#FF4444")
        )
    }
}
