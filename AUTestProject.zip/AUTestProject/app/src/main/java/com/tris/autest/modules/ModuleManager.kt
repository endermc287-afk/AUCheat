package com.tris.autest.modules

import android.content.Context
import com.tris.autest.game.GameConfig
import com.tris.autest.game.GameState
import com.tris.autest.utils.Settings

/**
 * Abstract base for every mod module.
 * [onGameTick] is called every game tick while the game is PLAYING.
 * [onEnabled] / [onDisabled] fire on toggle.
 */
abstract class BaseModule(
    val id: String,
    val displayName: String,
    val category: ModuleCategory
) {
    var enabled: Boolean = false
        set(value) {
            if (field == value) return
            field = value
            if (value) onEnabled() else onDisabled()
        }

    open fun onEnabled()  {}
    open fun onDisabled() {}
    open fun onGameTick(state: GameState, dt: Float) {}
}

enum class ModuleCategory(val label: String) {
    PLAYER("Player"),
    IMPOSTOR("Impostor"),
    DETECTOR("Detector"),
    ESP("ESP"),
    VISUALS("Visuals"),
    GAME("Game"),
    CONFIG("Config")
}

// ═══════════════════════════════════════════════════════════════════════════
// Manager — single source of truth for all modules
// ═══════════════════════════════════════════════════════════════════════════
class ModuleManager(private val context: Context) {

    // ── Instantiate all modules ────────────────────────────────────────────
    val alwaysImpostor    = AlwaysImpostorModule()
    val impostorDetector  = ImpostorDetectorModule()
    val impostorESP       = ImpostorESPModule()
    val espModule         = ESPModule()
    val speedHack         = SpeedHackModule()
    val noCooldown        = NoCooldownModule()
    val freecam           = FreecamModule()
    val infiniteVision    = InfiniteVisionModule()
    val customScale       = CustomScaleModule()

    val all: List<BaseModule> = listOf(
        alwaysImpostor, impostorDetector, impostorESP,
        espModule, speedHack, noCooldown, freecam,
        infiniteVision, customScale
    )

    // ── Grouped for menu ──────────────────────────────────────────────────
    fun byCategory(cat: ModuleCategory): List<BaseModule> = all.filter { it.category == cat }

    // ── Called every game tick by GameEngine ──────────────────────────────
    fun onGameTick(state: GameState, dt: Float) {
        all.filter { it.enabled }.forEach { it.onGameTick(state, dt) }
    }

    // ── Persistence ───────────────────────────────────────────────────────
    fun saveAll(settings: Settings) {
        all.forEach { settings.setBool("mod_${it.id}", it.enabled) }
        settings.setFloat("mod_speed_value", speedHack.multiplier)
        settings.commit()
    }

    fun loadAll(settings: Settings) {
        all.forEach { it.enabled = settings.getBool("mod_${it.id}", false) }
        speedHack.multiplier = settings.getFloat("mod_speed_value", 2f)
    }
}
