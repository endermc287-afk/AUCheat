package com.tris.autest.game

import android.graphics.PointF
import kotlin.math.sqrt

/** All possible roles a player can hold. */
enum class Role {
    CREWMATE,
    IMPOSTOR,
    GHOST_CREWMATE,
    GHOST_IMPOSTOR;

    val isImpostor: Boolean get() = this == IMPOSTOR || this == GHOST_IMPOSTOR
    val isGhost: Boolean get() = this == GHOST_CREWMATE || this == GHOST_IMPOSTOR
    val label: String get() = when (this) {
        CREWMATE -> "Crewmate"
        IMPOSTOR -> "Impostor"
        GHOST_CREWMATE -> "Ghost"
        GHOST_IMPOSTOR -> "Ghost (Imp)"
    }
}

/**
 * Represents a single player (local or bot) in the test game.
 *
 * [isLocal] = true for the one player the user controls.
 * All fields are mutable so the game engine can update them each tick.
 */
data class Player(
    val id: Int,
    val name: String,
    val playerColor: Int,          // ARGB colour for rendering
    val isLocal: Boolean = false,

    // --- state ---
    var role: Role = Role.CREWMATE,
    var position: PointF = PointF(0f, 0f),
    var velocity: PointF = PointF(0f, 0f),
    var isAlive: Boolean = true,
    var isInVent: Boolean = false,

    // --- mechanics ---
    var killCooldownMs: Long = 0L,  // remaining cooldown in ms, 0 = ready
    var tasksCompleted: Int = 0,
    var totalTasks: Int = GameConfig.TASKS_PER_CREWMATE,

    // --- bot AI ---
    var botTarget: PointF? = null,
    var botStateTimer: Long = 0L
) {
    val isImpostor: Boolean  get() = role.isImpostor
    val isGhost: Boolean     get() = role.isGhost
    val taskProgress: Float  get() = if (totalTasks == 0) 1f
                                     else tasksCompleted.toFloat() / totalTasks

    /** Distance to another player (Euclidean). */
    fun distanceTo(other: Player): Float {
        val dx = position.x - other.position.x
        val dy = position.y - other.position.y
        return sqrt(dx * dx + dy * dy)
    }

    /** Distance to an arbitrary world point. */
    fun distanceTo(pt: PointF): Float {
        val dx = position.x - pt.x
        val dy = position.y - pt.y
        return sqrt(dx * dx + dy * dy)
    }

    /** Convert this player to its ghost variant (called on death). */
    fun die() {
        role = if (role == Role.IMPOSTOR) Role.GHOST_IMPOSTOR else Role.GHOST_CREWMATE
        isAlive = false
        velocity.set(0f, 0f)
    }
}
