package com.tris.autest.game

import android.graphics.PointF
import android.graphics.RectF

/** A named room on the map. */
data class Room(
    val name: String,
    val bounds: RectF,
    val fillColor: Int   // ARGB
)

/** A task node players can interact with. */
data class TaskNode(
    val id: Int,
    val roomName: String,
    val position: PointF,
    var assignedTo: Int = -1,     // Player ID, -1 = unassigned
    var isComplete: Boolean = false
)

/** A vent (Impostors only). */
data class Vent(
    val id: Int,
    val position: PointF,
    val linkedVentIds: List<Int>  // IDs of vents this connects to
)

/**
 * Static Skeld-inspired map definition.
 * All units in world-space (pixels at 1:1 scale).
 * Origin (0,0) is top-left.
 */
object MapData {

    // ── Rooms ──────────────────────────────────────────────────────────────
    val rooms: List<Room> = listOf(
        Room("Cafeteria",    RectF(  80f,  80f,  600f, 440f), 0xFF1A1A2E.toInt()),
        Room("Weapons",      RectF( 620f,  80f,  960f, 320f), 0xFF16213E.toInt()),
        Room("Navigation",   RectF(1000f,  80f, 1340f, 320f), 0xFF0F3460.toInt()),
        Room("Admin",        RectF(1360f, 300f, 1700f, 540f), 0xFF1A1A2E.toInt()),
        Room("Storage",      RectF(1360f, 560f, 1700f, 820f), 0xFF16213E.toInt()),
        Room("Shields",      RectF(1360f, 840f, 1700f, 1100f),0xFF0F3460.toInt()),
        Room("MedBay",       RectF( 620f, 740f,  960f, 1000f),0xFF1A1A2E.toInt()),
        Room("Security",     RectF(  80f, 740f,  520f, 1000f),0xFF16213E.toInt()),
        Room("Reactor",      RectF(  80f, 460f,  440f, 720f), 0xFF0F3460.toInt()),
        Room("Engine Lower", RectF( 460f, 1020f, 800f, 1300f),0xFF1A1A2E.toInt()),
        Room("Engine Upper", RectF( 460f, 460f,  800f, 720f), 0xFF16213E.toInt()),
        Room("Electrical",   RectF( 820f, 1020f,1200f, 1300f),0xFF0F3460.toInt()),
        Room("Comms",        RectF(1200f, 1020f,1540f, 1300f),0xFF1A1A2E.toInt()),
    )

    // ── Spawn points ───────────────────────────────────────────────────────
    val spawnPoints: List<PointF> = listOf(
        PointF(300f, 240f),  // Cafeteria centre
        PointF(340f, 260f),
        PointF(260f, 220f),
        PointF(320f, 300f),
        PointF(280f, 280f),
        PointF(340f, 220f),
        PointF(260f, 300f),
        PointF(380f, 240f),
        PointF(220f, 260f),
        PointF(300f, 200f)
    )

    // ── Task nodes ─────────────────────────────────────────────────────────
    val taskNodes: List<TaskNode> = listOf(
        TaskNode(0,  "Cafeteria",    PointF( 180f, 160f)),
        TaskNode(1,  "Cafeteria",    PointF( 500f, 380f)),
        TaskNode(2,  "Weapons",      PointF( 790f, 180f)),
        TaskNode(3,  "Navigation",   PointF(1160f, 180f)),
        TaskNode(4,  "Navigation",   PointF(1300f, 260f)),
        TaskNode(5,  "Admin",        PointF(1540f, 420f)),
        TaskNode(6,  "Storage",      PointF(1420f, 640f)),
        TaskNode(7,  "Shields",      PointF(1600f, 960f)),
        TaskNode(8,  "MedBay",       PointF( 790f, 870f)),
        TaskNode(9,  "Security",     PointF( 300f, 870f)),
        TaskNode(10, "Reactor",      PointF( 160f, 580f)),
        TaskNode(11, "Reactor",      PointF( 380f, 620f)),
        TaskNode(12, "Engine Lower", PointF( 620f,1120f)),
        TaskNode(13, "Electrical",   PointF( 980f,1100f)),
        TaskNode(14, "Comms",        PointF(1360f,1140f)),
    )

    // ── Vents ──────────────────────────────────────────────────────────────
    val vents: List<Vent> = listOf(
        Vent(0, PointF( 480f, 390f), listOf(1, 4)),   // Cafeteria vent
        Vent(1, PointF( 870f, 480f), listOf(0, 2)),   // Engine Upper
        Vent(2, PointF( 870f,1150f), listOf(1, 3)),   // Engine Lower
        Vent(3, PointF(1340f, 740f), listOf(2, 4)),   // Storage
        Vent(4, PointF( 180f, 600f), listOf(3, 0)),   // Reactor
    )

    // ── Helpers ────────────────────────────────────────────────────────────
    fun roomAt(x: Float, y: Float): Room? =
        rooms.firstOrNull { it.bounds.contains(x, y) }

    fun nearestTaskNode(x: Float, y: Float, range: Float): TaskNode? =
        taskNodes.filter { !it.isComplete }
            .minByOrNull {
                val dx = it.position.x - x; val dy = it.position.y - y
                dx * dx + dy * dy
            }?.takeIf {
                val dx = it.position.x - x; val dy = it.position.y - y
                Math.sqrt((dx * dx + dy * dy).toDouble()) <= range
            }

    fun nearestVent(x: Float, y: Float, range: Float): Vent? =
        vents.minByOrNull {
            val dx = it.position.x - x; val dy = it.position.y - y
            dx * dx + dy * dy
        }?.takeIf {
            val dx = it.position.x - x; val dy = it.position.y - y
            Math.sqrt((dx * dx + dy * dy).toDouble()) <= range
        }

    /** Check if a point is inside any room (walkable area). */
    fun isWalkable(x: Float, y: Float): Boolean = rooms.any { it.bounds.contains(x, y) }

    /** Clamp a position so it stays inside the map bounds. */
    fun clampToMap(pt: PointF): PointF {
        return PointF(
            pt.x.coerceIn(0f, MapData.MAP_W),
            pt.y.coerceIn(0f, MapData.MAP_H)
        )
    }

    private const val MAP_W = GameConfig.MAP_WIDTH
    private const val MAP_H = GameConfig.MAP_HEIGHT
}
