package com.tris.autest.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.view.WindowManager.LayoutParams.*
import android.widget.*
import androidx.core.app.NotificationCompat
import com.tris.autest.R
import com.tris.autest.game.*
import com.tris.autest.modules.*
import com.tris.autest.utils.FPSCounter
import com.tris.autest.utils.Settings
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Foreground service that owns:
 *   1. The game engine + loop
 *   2. The in-game SurfaceView (full-screen)
 *   3. The floating icon (collapsed menu state)
 *   4. The floating panel (expanded menu)
 *   5. The FPS counter overlay
 */
class FloatingMenuService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var settings: Settings
    lateinit var moduleManager: ModuleManager
    private lateinit var state: GameState
    private lateinit var engine: GameEngine
    private lateinit var renderer: GameRenderer
    private lateinit var loop: GameLoop

    // ── Overlay views ─────────────────────────────────────────────────────
    private var gameView: View? = null
    private var iconView: View? = null
    private var panelView: View? = null
    private var fpsView: TextView? = null

    private var panelOpen = false

    // Category tab currently selected
    private var selectedCategory = ModuleCategory.PLAYER

    // ── Notification ──────────────────────────────────────────────────────
    companion object {
        const val CHANNEL_ID = "autest_channel"
        const val NOTIF_ID   = 1
        const val ACTION_STOP = "com.tris.autest.STOP"
    }

    // ══════════════════════════════════════════════════════════════════════
    // Lifecycle
    // ══════════════════════════════════════════════════════════════════════
    override fun onCreate() {
        super.onCreate()
        wm        = getSystemService(WINDOW_SERVICE) as WindowManager
        settings  = Settings(this)
        moduleManager = ModuleManager(this)
        moduleManager.loadAll(settings)

        state  = GameState()
        engine = GameEngine(state, moduleManager)
        renderer = GameRenderer(this, state, engine, moduleManager)
        loop   = GameLoop(engine) { renderer.render() }

        engine.initSession()

        startForeground(NOTIF_ID, buildNotification())
        addGameView()
        addFloatingIcon()
        addFpsOverlay()
        loop.start()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        loop.stop()
        moduleManager.saveAll(settings)
        removeView(gameView)
        removeView(iconView)
        removeView(panelView)
        removeView(fpsView)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ══════════════════════════════════════════════════════════════════════
    // Game view (full-screen SurfaceView)
    // ══════════════════════════════════════════════════════════════════════
    private fun addGameView() {
        val lp = layoutParams(MATCH_PARENT, MATCH_PARENT).apply {
            flags = FLAG_NOT_FOCUSABLE or FLAG_LAYOUT_IN_SCREEN
            format = PixelFormat.OPAQUE
            gravity = Gravity.TOP or Gravity.START
        }
        wm.addView(renderer, lp)
        gameView = renderer
    }

    // ══════════════════════════════════════════════════════════════════════
    // Floating icon (draggable)
    // ══════════════════════════════════════════════════════════════════════
    private fun addFloatingIcon() {
        val icon = buildIconView()
        val lp   = layoutParams(100, 100).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24; y = 240
            flags = FLAG_NOT_FOCUSABLE
            format = PixelFormat.TRANSLUCENT
        }
        setupDrag(icon, lp) { togglePanel() }
        wm.addView(icon, lp)
        iconView = icon
    }

    private fun buildIconView(): View {
        val tv = TextView(this).apply {
            text = "⚙"
            textSize = 28f
            setTextColor(Color.WHITE)
            setBackgroundResource(R.drawable.ic_menu_bg)
            gravity = Gravity.CENTER
        }
        return tv
    }

    // ══════════════════════════════════════════════════════════════════════
    // Floating panel
    // ══════════════════════════════════════════════════════════════════════
    private fun togglePanel() {
        if (panelOpen) closePanel() else openPanel()
    }

    private fun openPanel() {
        panelOpen = true
        val panel = buildPanel()
        val lp    = layoutParams(680, WRAP_CONTENT).apply {
            gravity = Gravity.TOP or Gravity.END
            y = 80
            flags = FLAG_NOT_TOUCH_MODAL or FLAG_WATCH_OUTSIDE_TOUCH
            format = PixelFormat.TRANSLUCENT
        }
        wm.addView(panel, lp)
        panelView = panel
    }

    private fun closePanel() {
        panelOpen = false
        removeView(panelView)
        panelView = null
    }

    private fun buildPanel(): View {
        // Root scroll container
        val root = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#EE0A0A14"))
            isVerticalScrollBarEnabled = false
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
        }
        root.addView(container)

        // ── Header ──
        container.addView(headerRow())

        // ── Search bar ──
        container.addView(searchBar(container))

        // ── Category tabs ──
        container.addView(categoryTabs(container))

        // ── Modules for selected category ──
        container.addView(modulesList(selectedCategory, container))

        // ── Detector panel (if Detector tab) ──
        if (selectedCategory == ModuleCategory.DETECTOR) {
            container.addView(detectorPanel())
        }

        return root
    }

    private fun headerRow(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, 12)
        }
        val title = TextView(this).apply {
            text = "AUTest Mod Menu"
            textSize = 20f
            setTextColor(Color.parseColor("#CC88FF"))
            layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        }
        val closeBtn = TextView(this).apply {
            text = "✕"
            textSize = 22f
            setTextColor(Color.WHITE)
            setPadding(12, 4, 12, 4)
            setOnClickListener { closePanel() }
        }
        val stopBtn = TextView(this).apply {
            text = "STOP"
            textSize = 14f
            setTextColor(Color.RED)
            setPadding(12, 4, 12, 4)
            setOnClickListener { stopSelf() }
        }
        row.addView(title)
        row.addView(stopBtn)
        row.addView(closeBtn)
        return row
    }

    private fun searchBar(container: LinearLayout): View {
        val et = EditText(this).apply {
            hint = "🔍  Search modules…"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 15f
            setBackgroundColor(Color.parseColor("#22FFFFFF"))
            setPadding(16, 10, 16, 10)
            val lp = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
            lp.bottomMargin = 10
            layoutParams = lp
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {
                    filterModules(s?.toString() ?: "", container)
                }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
        return et
    }

    private fun categoryTabs(container: LinearLayout): View {
        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        ModuleCategory.values().forEach { cat ->
            val tab = TextView(this).apply {
                text = cat.label
                textSize = 13f
                setPadding(18, 8, 18, 8)
                setTextColor(if (cat == selectedCategory) Color.parseColor("#CC88FF") else Color.GRAY)
                setBackgroundColor(
                    if (cat == selectedCategory) Color.parseColor("#33CC88FF")
                    else Color.parseColor("#11FFFFFF")
                )
                val lp = LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT)
                lp.marginEnd = 6
                layoutParams = lp
                setOnClickListener {
                    selectedCategory = cat
                    // Rebuild panel to reflect new category
                    closePanel()
                    openPanel()
                }
            }
            row.addView(tab)
        }
        scroll.addView(row)
        val lp = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        lp.bottomMargin = 12
        scroll.layoutParams = lp
        return scroll
    }

    private fun modulesList(cat: ModuleCategory, container: LinearLayout): LinearLayout {
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val mods = moduleManager.byCategory(cat)
        if (mods.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "No modules in this category."
                setTextColor(Color.GRAY)
                textSize = 14f
                setPadding(0, 8, 0, 8)
            })
        }
        mods.forEach { mod -> list.addView(moduleRow(mod)) }
        return list
    }

    private fun moduleRow(mod: BaseModule): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#22FFFFFF"))
            setPadding(16, 10, 16, 10)
            val lp = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
            lp.bottomMargin = 6
            layoutParams = lp
        }

        val nameView = TextView(this).apply {
            text = mod.displayName
            textSize = 15f
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        }

        val toggle = Switch(this).apply {
            isChecked = mod.enabled
            thumbTintList = android.content.res.ColorStateList.valueOf(
                if (mod.enabled) Color.parseColor("#CC88FF") else Color.GRAY
            )
            setOnCheckedChangeListener { _, isChecked ->
                mod.enabled = isChecked
                thumbTintList = android.content.res.ColorStateList.valueOf(
                    if (isChecked) Color.parseColor("#CC88FF") else Color.GRAY
                )
                nameView.setTextColor(
                    if (isChecked) Color.parseColor("#CC88FF") else Color.WHITE
                )
                moduleManager.saveAll(settings)
            }
        }

        // Extra slider for SpeedHack
        row.addView(nameView)
        row.addView(toggle)

        if (mod is SpeedHackModule) {
            val sliderRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(16, 4, 16, 8)
                val lp = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
                lp.bottomMargin = 2
                layoutParams = lp
            }
            val label = TextView(this).apply {
                text = "Speed: ${mod.multiplier}x"
                textSize = 13f
                setTextColor(Color.parseColor("#AAAAAA"))
                layoutParams = LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT)
            }
            val seek = SeekBar(this).apply {
                max = 50          // 1.0x to 6.0x (step 0.1)
                progress = ((mod.multiplier - 1f) * 10f).roundToInt().coerceIn(0, 50)
                layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                        mod.multiplier = 1f + p * 0.1f
                        label.text = "Speed: ${"%.1f".format(mod.multiplier)}x"
                        if (mod.enabled) GameConfig.activeSpeed = GameConfig.DEFAULT_SPEED * mod.multiplier
                    }
                    override fun onStartTrackingTouch(sb: SeekBar) {}
                    override fun onStopTrackingTouch(sb: SeekBar) {
                        moduleManager.saveAll(settings)
                    }
                })
            }
            sliderRow.addView(label)
            sliderRow.addView(seek)
            // Wrap into a container that includes the main row
            val wrapper = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                val lp = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
                lp.bottomMargin = 6
                layoutParams = lp
            }
            wrapper.addView(row)
            wrapper.addView(sliderRow)
            return wrapper
        }

        return row
    }

    // ── Detector panel ────────────────────────────────────────────────────
    private fun detectorPanel(): View {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 12, 0, 0)
        }

        val header = TextView(this).apply {
            text = "IMPOSTOR DETECTOR — Live Role Data"
            textSize = 14f
            setTextColor(Color.parseColor("#FF4444"))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, 8)
        }
        container.addView(header)

        if (!moduleManager.impostorDetector.enabled) {
            container.addView(TextView(this).apply {
                text = "Enable Impostor Detector module to see live data."
                setTextColor(Color.GRAY)
                textSize = 13f
            })
            return container
        }

        val snap = moduleManager.impostorDetector.snapshot
        if (snap.isEmpty()) {
            container.addView(TextView(this).apply {
                text = "Waiting for round to start…"
                setTextColor(Color.GRAY)
                textSize = 13f
            })
            return container
        }

        val countRow = TextView(this).apply {
            text = "Total Impostors: ${moduleManager.impostorDetector.impostorCount}"
            textSize = 14f
            setTextColor(Color.parseColor("#FF8888"))
            setPadding(0, 0, 0, 8)
        }
        container.addView(countRow)

        snap.sortedBy { it.isImpostor.not() }.forEach { entry ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(8, 6, 8, 6)
                setBackgroundColor(
                    if (entry.isImpostor) Color.parseColor("#33FF0000")
                    else Color.parseColor("#1100FF44")
                )
                val lp = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
                lp.bottomMargin = 4
                layoutParams = lp
            }
            val nameV = TextView(this).apply {
                text = entry.name
                textSize = 14f
                setTextColor(if (entry.isAlive) Color.WHITE else Color.GRAY)
                layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
            }
            val roleV = TextView(this).apply {
                text = if (entry.isAlive) entry.roleLabel else "DEAD"
                textSize = 14f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                setTextColor(
                    when {
                        !entry.isAlive   -> Color.GRAY
                        entry.isImpostor -> Color.RED
                        else             -> Color.parseColor("#44FF88")
                    }
                )
            }
            row.addView(nameV)
            row.addView(roleV)
            container.addView(row)
        }

        return container
    }

    // ── Filter modules by search text ─────────────────────────────────────
    private fun filterModules(query: String, container: LinearLayout) {
        // For simplicity, rebuild panel with filtered category view
        // A more efficient approach would use a RecyclerView but overlay ScrollView is safer
    }

    // ══════════════════════════════════════════════════════════════════════
    // FPS Overlay
    // ══════════════════════════════════════════════════════════════════════
    private fun addFpsOverlay() {
        val tv = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.parseColor("#AAFFAA"))
            setShadowLayer(3f, 0f, 0f, Color.BLACK)
            setPadding(8, 4, 8, 4)
        }
        val lp = layoutParams(WRAP_CONTENT, WRAP_CONTENT).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 12; y = 12
            flags = FLAG_NOT_FOCUSABLE or FLAG_NOT_TOUCHABLE
            format = PixelFormat.TRANSLUCENT
        }
        wm.addView(tv, lp)
        fpsView = tv

        // Update FPS text every second
        val handler = android.os.Handler(mainLooper)
        val runnable = object : Runnable {
            override fun run() {
                tv.text = "FPS: ${loop.fpsCounter.fps}"
                handler.postDelayed(this, 500)
            }
        }
        handler.post(runnable)
    }

    // ══════════════════════════════════════════════════════════════════════
    // Helpers
    // ══════════════════════════════════════════════════════════════════════
    private fun layoutParams(w: Int, h: Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            w, h,
            TYPE_APPLICATION_OVERLAY,
            FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )

    /** Attach drag + single-tap to a view using the given LayoutParams. */
    private fun setupDrag(
        view: View,
        lp: WindowManager.LayoutParams,
        onTap: () -> Unit
    ) {
        var downX = 0f; var downY = 0f
        var lpX   = 0;  var lpY   = 0
        var moved = false

        view.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX; downY = ev.rawY
                    lpX   = lp.x;   lpY   = lp.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downX; val dy = ev.rawY - downY
                    if (abs(dx) > 8 || abs(dy) > 8) {
                        moved = true
                        lp.x = (lpX + dx).toInt()
                        lp.y = (lpY + dy).toInt()
                        wm.updateViewLayout(view, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onTap()
                    true
                }
                else -> false
            }
        }
    }

    private fun removeView(v: View?) {
        try { v?.let { wm.removeView(it) } } catch (_: Exception) {}
    }

    // ── Notification ──────────────────────────────────────────────────────
    private fun buildNotification(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL_ID, "AUTest", NotificationManager.IMPORTANCE_LOW).apply {
            description = "AUTest game overlay"
        }
        nm.createNotificationChannel(ch)

        val stopIntent = android.app.PendingIntent.getService(
            this, 0,
            Intent(this, FloatingMenuService::class.java).apply { action = ACTION_STOP },
            android.app.PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("AUTest Running")
            .setContentText("Tap STOP to exit")
            .setSmallIcon(R.drawable.ic_notification)
            .addAction(0, "STOP", stopIntent)
            .setOngoing(true)
            .build()
    }
}
