package com.tris.autest

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class OverlayPermissionActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        AlertDialog.Builder(this)
            .setTitle("Overlay Permission Required")
            .setMessage(
                "AUTest needs the \"Display over other apps\" permission to show " +
                "the floating game overlay.\n\nTap GRANT to open system settings."
            )
            .setPositiveButton("GRANT") { _, _ ->
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
            .setNegativeButton("CANCEL") { _, _ -> finish() }
            .setCancelable(false)
            .show()
    }

    override fun onResume() {
        super.onResume()
        // If permission was granted while in settings, return to main
        if (Settings.canDrawOverlays(this)) {
            finish()
        }
    }
}
