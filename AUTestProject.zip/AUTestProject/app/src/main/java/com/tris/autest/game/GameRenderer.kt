package com.tris.autest.game

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import com.tris.autest.modules.ModuleManager
import kotlin.math.*

/**
 * SurfaceView that draws the entire game world + HUD + ESP.
 * Owns touch input routing (joystick + action buttons).
 */
@SuppressLint("ViewConstructor")
class GameRenderer(
    context: Context,
    private val state: GameState,
    private val engine: GameEngine,
    private val moduleManager: ModuleManager
) : SurfaceView(context), SurfaceHolder.Callback {

    // ── Paints ─────────────────────────────────────────────────────────────
    private val bgPaint        = Paint().apply { color = Color.parseColor("#0A0A14") }
    private val roomPaint      = Paint(Paint.ANTI_ALIAS_FLAG)
    private val roomBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#2A2A4A"); style = Paint.Style.STROKE; strokeWidth = 2f
    }
    private val playerPaint    = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ghostPaint     = Paint(Paint.ANTI_ALIAS_FLAG).apply { alpha = 90 }
    private val textPaint      = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 22f; textAlign = Paint.Align.CENTER
    }
    private val espTextPaint   = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 24f; textAlign = Paint.Align.CENTER
        setShadowLayer(4f, 0f, 0f, Color.BLACK)
    }
    private val espBoxPaint    = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2f
    }
    private val taskBarBgPaint = Paint().apply { color = Color.parseColor("#222233") }
    private val taskBarFgPaint = Paint().apply { color = Color.parseColor("#44FF88") }
    private val notifPaint     = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 28f; textAlign = Paint.Align.CENTER
        setShadowLayer(6f, 0f, 0f, Color.BLACK)
    }
    private val hudPaint       = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 26f; color = Color.WHITE
        setShadowLayer(3f, 0f, 0f, Color.BLACK)
    }
    private val cooldownPaint  = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 22f; textAlign = Paint.Align.CENTER; color = Color.WHITE
    }

    // ── Camera transform ───────────────────────────────────────────────────
    private val camera = Camera2D()

    // ── Joystick ───────────────────────────────────────────────────────────
    private val joystick = VirtualJoystick()

    // ── Action button regions (screen space) ──────────────────────────────
    private data class ActionButton(
        val label: String,
        var cx: Float = 0f,
        var cy: Float = 0f,
        val radius: Float = 56f,
        var visible: Boolean = true,
        var enabled: Boolean = true
    )

    private val btnKill  = ActionButton("KILL",  radius = 60f)
    private val btnTask  = ActionButton("TASK",  radius = 56f)
    private val btnVent  = ActionButton("VENT",  radius = 50f)
    private val btnMeet  = ActionButton("MEET",  radius = 50f)
    private val btnStart = ActionButton("START", radius = 70f)

    private val btnPaint  = Paint(Paint.ANTI_ALIAS_FLAG)
    private val btnText   = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER
        textSize = 20f; isFakeBoldText = true
        setShadowLayer(3f, 0f, 0f, Color.BLACK)
    }

    // ── Dead body marker ──────────────────────────────────────────────────
    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.RED }
    private val bodyText  = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.RED; textSize = 20f; textAlign = Paint.Align.CENTER
    }

    // ── Vent marker ───────────────────────────────────────────────────────
    private val ventPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#AA44CC"); style = Paint.Style.STROKE; strokeWidth = 3f
    }

    init {
        holder.addCallback(this)
        setZOrderOnTop(false)
    }

    // ── SurfaceHolder callbacks ────────────────────────────────────────────
    override fun surfaceCreated(h: SurfaceHolder) {}
    override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, h2: Int) {
        layoutButtons(w.toFloat(), h2.toFloat())
        camera.viewW = w.toFloat()
        camera.viewH = h2.toFloat()
    }
    override fun surfaceDestroyed(h: SurfaceHolder) {}

    // ── Render entry (called by GameLoop) ─────────────────────────────────
    fun render() {
        val h = holder.takeIf { it.surface.isValid } ?: return
        val canvas = h.lockCanvas() ?: return
        try {
            drawFrame(canvas)
        } finally {
            h.unlockCanvasAndPost(canvas)
        }
    }

    private fun drawFrame(canvas: Canvas) {
        val W = canvas.width.toFloat()
        val H = canvas.height.toFloat()

        canvas.drawRect(0f, 0f, W, H, bgPaint)

        synchronized(state.lock) {
            // Camera follows local player (or freecam target)
            val camTarget = state.cameraTarget
            camera.update(camTarget.x, camTarget.y, state.cameraZoom)

            canvas.save()
            canvas.translate(camera.offsetX, camera.offsetY)
            canvas.scale(camera.zoom, camera.zoom, camTarget.x, camTarget.y)

            drawMap(canvas)
            drawVents(canvas)
            drawDeadBodies(canvas)
            drawPlayers(canvas)
            if (moduleManager.espModule.enabled) drawESP(canvas)

            canvas.restore()

            // HUD (screen space)
            drawTaskBar(canvas, W, H)
            drawNotifications(canvas, W, H)
            drawHUD(canvas, W, H)
            drawActionButtons(canvas, W, H)
            drawJoystick(canvas)

            if (state.phase == GamePhase.LOBBY) drawStartButton(canvas, W, H)
            if (state.phase == GamePhase.ROUND_END) drawRoundEnd(canvas, W, H)
        }
    }

    // ── Map ───────────────────────────────────────────────────────────────
    private fun drawMap(canvas: Canvas) {
        MapData.rooms.forEach { room ->
            roomPaint.color = room.fillColor
            canvas.drawRoundRect(RectF(room.bounds), 12f, 12f, roomPaint)
            canvas.drawRoundRect(RectF(room.bounds), 12f, 12f, roomBorderPaint)

            // Room label
            textPaint.textSize = 20f
            textPaint.color = Color.parseColor("#4444AA")
            canvas.drawText(
                room.name,
                room.bounds.centerX(),
                room.bounds.centerY() + 7f,
                textPaint
            )
        }

        // Task nodes
        MapData.taskNodes.forEach { node ->
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = if (node.isComplete) Color.parseColor("#44FF88")
                        else Color.parseColor("#FFAA00")
                style = Paint.Style.FILL
            }
            canvas.drawCircle(node.position.x, node.position.y, 10f, paint)
            val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 1.5f
            }
            canvas.drawCircle(node.position.x, node.position.y, 10f, border)
        }
    }

    private fun drawVents(canvas: Canvas) {
        MapData.vents.forEach { vent ->
            canvas.drawCircle(vent.position.x, vent.position.y, 14f, ventPaint)
            val inner = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#550077"); style = Paint.Style.FILL
            }
            canvas.drawCircle(vent.position.x, vent.position.y, 10f, inner)
        }
    }

    private fun drawDeadBodies(canvas: Canvas) {
        state.deadBodies.forEach { body ->
            // X cross marker
            val s = 14f
            canvas.drawLine(body.position.x - s, body.position.y - s,
                            body.position.x + s, body.position.y + s, bodyPaint)
            canvas.drawLine(body.position.x + s, body.position.y - s,
                            body.position.x - s, body.position.y + s, bodyPaint)
        }
    }

    // ── Players ───────────────────────────────────────────────────────────
    private fun drawPlayers(canvas: Canvas) {
        state.players.forEach { p ->
            if (p.isInVent) return@forEach

            val lp = state.localPlayer
            // Vision check: only draw if within vision radius (or ghost/local)
            val inVision = lp == null || p.isLocal || lp.isGhost ||
                (lp.isImpostor) ||
                (lp.distanceTo(p) <= GameConfig.activeVisionRadius)

            if (!inVision) return@forEach

            val r = GameConfig.PLAYER_RADIUS
            val paint = if (p.isGhost) ghostPaint else playerPaint
            paint.color = p.playerColor
            paint.style = Paint.Style.FILL

            canvas.drawCircle(p.position.x, p.position.y, r, paint)

            // Outline
            val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = if (p.isLocal) Color.WHITE else Color.parseColor("#AAAAAA")
                style = Paint.Style.STROKE
                strokeWidth = if (p.isLocal) 3f else 1.5f
            }
            canvas.drawCircle(p.position.x, p.position.y, r, outline)

            // Name tag
            textPaint.textSize = 20f
            textPaint.color = Color.WHITE
            canvas.drawText(p.name, p.position.x, p.position.y - r - 6f, textPaint)

            // Vent indicator
            if (p.isInVent) {
                textPaint.color = Color.MAGENTA
                canvas.drawText("[V]", p.position.x, p.position.y + r + 20f, textPaint)
            }
        }
    }

    // ── ESP ───────────────────────────────────────────────────────────────
    private fun drawESP(canvas: Canvas) {
        val lp = state.localPlayer ?: return
        state.players.filter { it.id != lp.id && !it.isInVent }.forEach { p ->
            val espColor = when {
                p.isImpostor && p.isAlive -> Color.RED
                !p.isAlive                -> Color.parseColor("#888888")
                else                      -> Color.parseColor("#00FF66")
            }

            // Bounding box
            val r = GameConfig.PLAYER_RADIUS + 8f
            espBoxPaint.color = espColor
            canvas.drawRect(p.position.x - r, p.position.y - r,
                            p.position.x + r, p.position.y + r, espBoxPaint)

            // Name + role + distance
            espTextPaint.color = espColor
            val dist = lp.distanceTo(p).toInt()
            val roleLabel = if (moduleManager.impostorDetector.enabled) p.role.label else "???"
            espTextPaint.textSize = 20f
            canvas.drawText("${p.name} [$roleLabel]", p.position.x, p.position.y - r - 24f, espTextPaint)
            espTextPaint.textSize = 17f
            canvas.drawText("${dist}u", p.position.x, p.position.y - r - 6f, espTextPaint)
        }
    }

    // ── HUD ───────────────────────────────────────────────────────────────
    private fun drawTaskBar(canvas: Canvas, W: Float, H: Float) {
        val barW = W * 0.5f; val barH = 14f
        val left = (W - barW) / 2f; val top = 12f
        canvas.drawRoundRect(left, top, left + barW, top + barH, 7f, 7f, taskBarBgPaint)
        val prog = state.taskBarProgress
        if (prog > 0f) {
            canvas.drawRoundRect(left, top, left + barW * prog, top + barH, 7f, 7f, taskBarFgPaint)
        }
        hudPaint.textSize = 18f
        hudPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("Tasks ${(prog * 100).toInt()}%", W / 2f, top + barH + 20f, hudPaint)
        hudPaint.textAlign = Paint.Align.LEFT
    }

    private fun drawHUD(canvas: Canvas, W: Float, H: Float) {
        val lp = state.localPlayer ?: return
        hudPaint.textSize = 24f

        val roleColor = if (lp.isImpostor) Color.RED else Color.parseColor("#44FF88")
        hudPaint.color = roleColor
        canvas.drawText("● ${lp.role.label.uppercase()}", 16f, H - 240f, hudPaint)

        hudPaint.color = Color.WHITE
        hudPaint.textSize = 20f
        canvas.drawText("Round: ${state.roundNumber}", 16f, H - 212f, hudPaint)
        canvas.drawText("Alive: ${state.alivePlayers.size}/${state.players.size}", 16f, H - 188f, hudPaint)
        canvas.drawText("Imp: ${state.aliveImpostors.size}", 16f, H - 164f, hudPaint)

        // Kill cooldown bar (Impostors only)
        if (lp.isImpostor && lp.isAlive) {
            val cdMax  = GameConfig.activeKillCooldownMs.toFloat()
            val cdLeft = lp.killCooldownMs.toFloat()
            val cdProg = if (GameConfig.noKillCooldown || cdMax == 0f) 1f else 1f - (cdLeft / cdMax)
            val bw = 160f; val bh = 18f; val bx = 16f; val by = H - 148f

            val bgCd = Paint().apply { color = Color.parseColor("#440000") }
            val fgCd = Paint().apply {
                color = if (cdProg >= 1f) Color.RED else Color.parseColor("#FF4444")
            }
            canvas.drawRoundRect(bx, by, bx + bw, by + bh, 9f, 9f, bgCd)
            canvas.drawRoundRect(bx, by, bx + bw * cdProg, by + bh, 9f, 9f, fgCd)
            cooldownPaint.textAlign = Paint.Align.LEFT
            cooldownPaint.textSize  = 18f
            cooldownPaint.color     = Color.WHITE
            canvas.drawText(
                if (GameConfig.noKillCooldown) "KILL READY" else "CD: ${cdLeft.toInt() / 1000}s",
                bx + 4f, by + bh - 2f, cooldownPaint
            )
        }
    }

    private fun drawNotifications(canvas: Canvas, W: Float, H: Float) {
        var y = H * 0.35f
        state.notifications.forEach { n ->
            notifPaint.color = n.color
            canvas.drawText(n.message, W / 2f, y, notifPaint)
            y += 36f
        }
    }

    // ── Action Buttons ────────────────────────────────────────────────────
    private fun layoutButtons(W: Float, H: Float) {
        val baseY = H - 90f
        btnKill.cx  = W - 90f;  btnKill.cy  = baseY
        btnTask.cx  = W - 90f;  btnTask.cy  = baseY - 140f
        btnVent.cx  = W - 170f; btnVent.cy  = baseY
        btnMeet.cx  = W - 170f; btnMeet.cy  = baseY - 140f
        btnStart.cx = W / 2f;   btnStart.cy = H / 2f
    }

    private fun drawActionButtons(canvas: Canvas, W: Float, H: Float) {
        val lp = state.localPlayer
        if (state.phase != GamePhase.PLAYING || lp == null || !lp.isAlive) return

        // KILL (Impostors only)
        if (lp.isImpostor) {
            val ready = lp.killCooldownMs == 0L || GameConfig.noKillCooldown
            drawBtn(canvas, btnKill, if (ready) Color.RED else Color.parseColor("#661111"), "KILL")
        }

        // TASK (Crewmates only)
        if (!lp.isImpostor) {
            val nearTask = MapData.nearestTaskNode(lp.position.x, lp.position.y, GameConfig.TASK_INTERACT_RANGE)
                ?.takeIf { it.assignedTo == lp.id } != null
            drawBtn(canvas, btnTask, if (nearTask) Color.parseColor("#44FF88") else Color.DKGRAY, "TASK")
        }

        // VENT (Impostors only)
        if (lp.isImpostor) {
            val nearVent = MapData.nearestVent(lp.position.x, lp.position.y, GameConfig.TASK_INTERACT_RANGE) != null
            drawBtn(canvas, btnVent, if (nearVent) Color.MAGENTA else Color.DKGRAY, if (lp.isInVent) "EXIT" else "VENT")
        }

        // EMERGENCY
        drawBtn(canvas, btnMeet, Color.parseColor("#FFAA00"), "MEET")
    }

    private fun drawStartButton(canvas: Canvas, W: Float, H: Float) {
        drawBtn(canvas, btnStart, Color.parseColor("#6622CC"), "START GAME")
    }

    private fun drawRoundEnd(canvas: Canvas, W: Float, H: Float) {
        val overlay = Paint().apply { color = Color.parseColor("#AA000000") }
        canvas.drawRect(0f, 0f, W, H, overlay)
        val t = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 48f; textAlign = Paint.Align.CENTER; color = Color.WHITE
            isFakeBoldText = true; setShadowLayer(8f, 0f, 0f, Color.BLACK)
        }
        val msg = when (state.winCondition) {
            WinCondition.CREWMATES_WIN -> "CREWMATES WIN"
            WinCondition.IMPOSTORS_WIN -> "IMPOSTORS WIN"
            else -> "ROUND ENDED"
        }
        canvas.drawText(msg, W / 2f, H / 2f - 40f, t)
        t.textSize = 28f
        canvas.drawText("Tap START to play again", W / 2f, H / 2f + 20f, t)
        // Reuse start button position
        btnStart.cx = W / 2f; btnStart.cy = H / 2f + 100f
        drawBtn(canvas, btnStart, Color.parseColor("#6622CC"), "NEW ROUND")
    }

    private fun drawBtn(canvas: Canvas, btn: ActionButton, color: Int, label: String) {
        btnPaint.color = color
        btnPaint.style = Paint.Style.FILL
        btnPaint.alpha = 200
        canvas.drawCircle(btn.cx, btn.cy, btn.radius, btnPaint)
        btnPaint.color = Color.WHITE; btnPaint.style = Paint.Style.STROKE
        btnPaint.strokeWidth = 2f; btnPaint.alpha = 255
        canvas.drawCircle(btn.cx, btn.cy, btn.radius, btnPaint)
        btnText.textSize = if (label.length > 5) 16f else 20f
        canvas.drawText(label, btn.cx, btn.cy + 7f, btnText)
    }

    // ── Joystick ───────────────────────────────────────────────────────────
    private fun drawJoystick(canvas: Canvas) {
        if (state.phase != GamePhase.PLAYING) return
        val lp = state.localPlayer
        if (lp == null || !lp.isAlive) return
        joystick.draw(canvas)
    }

    // ── Touch ─────────────────────────────────────────────────────────────
    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x; val y = event.y

        // Joystick eats left-side touches
        if (joystick.onTouch(event, engine)) return true

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                when {
                    state.phase == GamePhase.LOBBY || state.phase == GamePhase.ROUND_END -> {
                        if (dist(x, y, btnStart.cx, btnStart.cy) < btnStart.radius + 10f) {
                            if (state.phase == GamePhase.LOBBY) engine.startRound()
                            else engine.initSession().also { engine.startRound() }
                        }
                    }
                    state.phase == GamePhase.PLAYING -> {
                        val lp = state.localPlayer
                        if (lp != null && lp.isAlive) {
                            when {
                                lp.isImpostor && dist(x, y, btnKill.cx, btnKill.cy) < btnKill.radius + 10f ->
                                    engine.attemptKill()
                                !lp.isImpostor && dist(x, y, btnTask.cx, btnTask.cy) < btnTask.radius + 10f ->
                                    engine.attemptTask()
                                lp.isImpostor && dist(x, y, btnVent.cx, btnVent.cy) < btnVent.radius + 10f ->
                                    engine.attemptVent()
                                dist(x, y, btnMeet.cx, btnMeet.cy) < btnMeet.radius + 10f ->
                                    engine.callEmergencyMeeting()
                            }
                        }
                    }
                }
            }
        }
        return true
    }

    private fun dist(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x1 - x2; val dy = y1 - y2
        return sqrt(dx * dx + dy * dy)
    }

    // ── Inner: simple 2D camera ────────────────────────────────────────────
    inner class Camera2D {
        var viewW = 1080f; var viewH = 1920f
        var zoom = 1.0f
        var offsetX = 0f; var offsetY = 0f

        fun update(targetX: Float, targetY: Float, z: Float) {
            zoom = z
            offsetX = viewW / 2f - targetX * zoom
            offsetY = viewH / 2f - targetY * zoom
        }
    }
}

// ── Virtual Joystick ──────────────────────────────────────────────────────────
class VirtualJoystick {
    private val DEAD_ZONE = 0.1f
    private val BASE_RADIUS = 90f
    private val KNOB_RADIUS = 42f
    private val MAX_DRAG    = BASE_RADIUS

    private var baseX = 0f; private var baseY = 0f
    private var knobX = 0f; private var knobY = 0f
    private var active = false
    private var pointerId = -1

    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#44FFFFFF"); style = Paint.Style.FILL
    }
    private val baseBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#88FFFFFF"); style = Paint.Style.STROKE; strokeWidth = 2f
    }
    private val knobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#AAFFFFFF")
    }

    private val defaultBaseX get() = 180f
    private val defaultBaseY get() = 0f   // set during draw

    private var canvasH = 0f

    fun draw(canvas: Canvas) {
        canvasH = canvas.height.toFloat()
        val bx = if (active) baseX else defaultBaseX
        val by = if (active) baseY else canvasH - 180f
        val kx = if (active) knobX else bx
        val ky = if (active) knobY else by

        canvas.drawCircle(bx, by, BASE_RADIUS, basePaint)
        canvas.drawCircle(bx, by, BASE_RADIUS, baseBorder)
        canvas.drawCircle(kx, ky, KNOB_RADIUS, knobPaint)
    }

    /** Returns true if this joystick handled the event. */
    fun onTouch(event: MotionEvent, engine: GameEngine): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val x = event.getX(0); val y = event.getY(0)
                if (x < 400f && y > canvasH * 0.4f) {
                    active = true; pointerId = event.getPointerId(0)
                    baseX = x; baseY = y; knobX = x; knobY = y
                    updateInput(engine, 0f, 0f)
                    return true
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (!active) return false
                val idx = event.findPointerIndex(pointerId).takeIf { it >= 0 } ?: return false
                val dx = event.getX(idx) - baseX
                val dy = event.getY(idx) - baseY
                val dist = sqrt(dx * dx + dy * dy)
                val clamped = dist.coerceAtMost(MAX_DRAG)
                val angle   = atan2(dy, dx)
                knobX = baseX + cos(angle) * clamped
                knobY = baseY + sin(angle) * clamped
                val norm = clamped / MAX_DRAG
                val nx = if (norm > DEAD_ZONE) cos(angle) * norm else 0f
                val ny = if (norm > DEAD_ZONE) sin(angle) * norm else 0f
                updateInput(engine, nx, ny)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                if (active && event.findPointerIndex(pointerId) >= 0) {
                    active = false; pointerId = -1
                    updateInput(engine, 0f, 0f)
                    return true
                }
            }
        }
        return false
    }

    private fun updateInput(engine: GameEngine, dx: Float, dy: Float) {
        engine.inputDx = dx
        engine.inputDy = dy
    }
}
