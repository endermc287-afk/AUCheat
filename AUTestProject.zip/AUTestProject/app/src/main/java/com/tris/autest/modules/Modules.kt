package com.tris.autest.modules

import android.graphics.Color
import android.graphics.PointF
import com.tris.autest.game.GameConfig
import com.tris.autest.game.GamePhase
import com.tris.autest.game.GameState
import com.tris.autest.game.Role

// ══════════════════════════════════════════════════════════════════
// A. ALWAYS IMPOSTOR
// Forces the local player's role to Impostor every round.
// Applied during role-assignment phase via GameConfig flag +
// per-tick enforcement so a reload doesn't strip the role.
// ══════════════════════════════════════════════════════════════════
class AlwaysImpostorModule : BaseModule(
    id = "always_impostor",
    displayName = "Always Impostor",
    category = ModuleCategory.IMPOSTOR
) {
    override fun onEnabled()  { GameConfig.alwaysImpostorEnabled = true  }
    override fun onDisabled() { GameConfig.alwaysImpostorEnabled = false }

    override fun onGameTick(state: GameState, dt: Float) {
        if (state.phase != GamePhase.PLAYING) return
        val lp = state.localPlayer ?: return
        // If role somehow slipped, enforce it immediately
        if (!lp.isImpostor && lp.isAlive) {
            // Swap with a bot impostor so the count stays correct
            val botImp = state.players.firstOrNull { it.isImpostor && !it.isLocal }
            if (botImp != null) {
                botImp.role = Role.CREWMATE
                lp.role     = Role.IMPOSTOR
                lp.killCooldownMs = GameConfig.activeKillCooldownMs
                state.postNotification("Always Impostor: role enforced", Color.RED)
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════════
// B. IMPOSTOR DETECTOR
// Reads role data from GameState and publishes it to the UI.
// No game logic mutation — purely observational.
// ══════════════════════════════════════════════════════════════════
class ImpostorDetectorModule : BaseModule(
    id = "impostor_detector",
    displayName = "Impostor Detector",
    category = ModuleCategory.DETECTOR
) {
    // Snapshot exposed to FloatingMenuService for display
    data class DetectorEntry(
        val playerId: Int,
        val name: String,
        val roleLabel: String,
        val isImpostor: Boolean,
        val isAlive: Boolean
    )

    var snapshot: List<DetectorEntry> = emptyList()
        private set

    var impostorCount: Int = 0
        private set

    override fun onGameTick(state: GameState, dt: Float) {
        if (state.phase != GamePhase.PLAYING && state.phase != GamePhase.DISCUSSION) return
        snapshot = state.players.map { p ->
            DetectorEntry(
                playerId  = p.id,
                name      = p.name,
                roleLabel = p.role.label,
                isImpostor = p.isImpostor,
                isAlive   = p.isAlive
            )
        }
        impostorCount = state.players.count { it.isImpostor }
    }

    override fun onDisabled() {
        snapshot = emptyList()
        impostorCount = 0
    }
}

// ══════════════════════════════════════════════════════════════════
// C. IMPOSTOR ESP
// Flags impostor positions for the renderer. The renderer reads
// ESPModule.enabled to decide whether to draw ESP overlays;
// this module additionally colours impostors in red regardless
// of vision radius so they always show through walls.
// ══════════════════════════════════════════════════════════════════
class ImpostorESPModule : BaseModule(
    id = "impostor_esp",
    displayName = "Impostor ESP",
    category = ModuleCategory.ESP
) {
    // Renderer checks this flag to bypass vision check for impostors
    var forceShowImpostors: Boolean = false

    override fun onEnabled()  { forceShowImpostors = true  }
    override fun onDisabled() {
        forceShowImpostors = false
        notified.clear()
    }

    override fun onGameTick(state: GameState, dt: Float) {
        // Posts a notification when a new impostor is spotted in range
        // (fires once per round per impostor)
        if (state.phase != GamePhase.PLAYING) return
        val lp = state.localPlayer ?: return
        if (!lp.isLocal) return

        state.aliveImpostors.filter { it.id != lp.id }.forEach { imp ->
            val key = "esp_notified_${imp.id}_${state.roundNumber}"
            if (!notified.contains(key) && lp.distanceTo(imp) < GameConfig.activeVisionRadius * 2f) {
                state.postNotification("ESP: ${imp.name} is Impostor!", Color.RED, 3000L)
                notified.add(key)
            }
        }
    }

    private val notified = mutableSetOf<String>()
}

// ══════════════════════════════════════════════════════════════════
// D. FULL ESP (all players)
// ══════════════════════════════════════════════════════════════════
class ESPModule : BaseModule(
    id = "esp",
    displayName = "Player ESP",
    category = ModuleCategory.ESP
) {
    // Renderer checks espModule.enabled directly — no extra tick logic needed
    override fun onEnabled()  {}
    override fun onDisabled() {}
}

// ══════════════════════════════════════════════════════════════════
// E. SPEED HACK
// ══════════════════════════════════════════════════════════════════
class SpeedHackModule : BaseModule(
    id = "speed_hack",
    displayName = "Speed Hack",
    category = ModuleCategory.PLAYER
) {
    var multiplier: Float = 2.5f   // settable from menu slider

    override fun onEnabled()  { GameConfig.activeSpeed = GameConfig.DEFAULT_SPEED * multiplier }
    override fun onDisabled() { GameConfig.activeSpeed = GameConfig.DEFAULT_SPEED }

    override fun onGameTick(state: GameState, dt: Float) {
        // Keep in sync if multiplier was changed at runtime
        GameConfig.activeSpeed = GameConfig.DEFAULT_SPEED * multiplier
    }
}

// ══════════════════════════════════════════════════════════════════
// F. NO COOLDOWN
// ══════════════════════════════════════════════════════════════════
class NoCooldownModule : BaseModule(
    id = "no_cooldown",
    displayName = "No Cooldown",
    category = ModuleCategory.IMPOSTOR
) {
    override fun onEnabled()  { GameConfig.noKillCooldown = true  }
    override fun onDisabled() { GameConfig.noKillCooldown = false }

    override fun onGameTick(state: GameState, dt: Float) {
        if (state.phase != GamePhase.PLAYING) return
        // Zero out every impostor's cooldown every tick
        state.players.filter { it.isImpostor && it.isAlive }.forEach { it.killCooldownMs = 0L }
    }
}

// ══════════════════════════════════════════════════════════════════
// G. FREECAM
// Decouples camera from the local player.
// The user drags the game view to pan; pinch to zoom.
// ══════════════════════════════════════════════════════════════════
class FreecamModule : BaseModule(
    id = "freecam",
    displayName = "Freecam",
    category = ModuleCategory.PLAYER
) {
    // Camera target is written here; GameState reads it
    var targetX: Float = GameConfig.MAP_WIDTH  / 2f
    var targetY: Float = GameConfig.MAP_HEIGHT / 2f
    var zoom:    Float = 0.5f    // zoomed out to see more map

    override fun onEnabled() {
        GameConfig.freecamEnabled = true
    }

    override fun onDisabled() {
        GameConfig.freecamEnabled = false
        zoom = 1.0f
    }

    override fun onGameTick(state: GameState, dt: Float) {
        if (!enabled) return
        // Push camera target into GameState every tick
        state.cameraTarget.set(targetX, targetY)
        state.cameraZoom = zoom
    }

    /** Called by touch handler when freecam is active. */
    fun pan(dx: Float, dy: Float) {
        targetX = (targetX - dx / zoom).coerceIn(0f, GameConfig.MAP_WIDTH)
        targetY = (targetY - dy / zoom).coerceIn(0f, GameConfig.MAP_HEIGHT)
    }

    fun pinchZoom(factor: Float) {
        zoom = (zoom * factor).coerceIn(0.25f, 2.0f)
    }
}

// ══════════════════════════════════════════════════════════════════
// H. INFINITE VISION
// ══════════════════════════════════════════════════════════════════
class InfiniteVisionModule : BaseModule(
    id = "infinite_vision",
    displayName = "Infinite Vision",
    category = ModuleCategory.PLAYER
) {
    override fun onEnabled()  { GameConfig.activeVisionRadius = Float.MAX_VALUE }
    override fun onDisabled() { GameConfig.activeVisionRadius = GameConfig.DEFAULT_VISION_RADIUS }
}

// ══════════════════════════════════════════════════════════════════
// I. CUSTOM SCALE (player render radius override)
// ══════════════════════════════════════════════════════════════════
class CustomScaleModule : BaseModule(
    id = "custom_scale",
    displayName = "Custom Player Scale",
    category = ModuleCategory.VISUALS
) {
    // Renderer reads GameConfig.PLAYER_RADIUS — we override at runtime via reflection isn't
    // possible on a const, so we expose a multiplier the renderer checks
    var scaleMult: Float = 1.5f
    var activeRadius: Float = GameConfig.PLAYER_RADIUS

    override fun onEnabled()  { activeRadius = GameConfig.PLAYER_RADIUS * scaleMult }
    override fun onDisabled() { activeRadius = GameConfig.PLAYER_RADIUS }
}
