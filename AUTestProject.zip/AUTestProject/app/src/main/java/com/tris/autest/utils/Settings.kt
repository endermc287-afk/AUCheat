package com.tris.autest.utils

import android.content.Context
import android.content.SharedPreferences

/**
 * Thin wrapper around SharedPreferences.
 * All reads are synchronous; writes are batched and committed via [commit].
 */
class Settings(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("autest_prefs", Context.MODE_PRIVATE)

    private var editor: SharedPreferences.Editor = prefs.edit()

    fun getBool(key: String, default: Boolean = false): Boolean = prefs.getBoolean(key, default)
    fun getFloat(key: String, default: Float = 0f): Float       = prefs.getFloat(key, default)
    fun getInt(key: String, default: Int = 0): Int              = prefs.getInt(key, default)
    fun getString(key: String, default: String = ""): String    = prefs.getString(key, default) ?: default

    fun setBool(key: String, value: Boolean)   { editor.putBoolean(key, value) }
    fun setFloat(key: String, value: Float)    { editor.putFloat(key, value)   }
    fun setInt(key: String, value: Int)        { editor.putInt(key, value)     }
    fun setString(key: String, value: String)  { editor.putString(key, value)  }

    /** Flush all pending edits to disk. */
    fun commit() {
        editor.apply()
        editor = prefs.edit()
    }
}
