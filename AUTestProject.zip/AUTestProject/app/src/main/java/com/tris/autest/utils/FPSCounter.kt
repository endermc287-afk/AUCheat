package com.tris.autest.utils

/**
 * Rolling-window FPS counter.
 * Call [frame] once per rendered frame; read [fps] at any time.
 */
class FPSCounter {
    private var frameCount = 0
    private var lastTime   = System.nanoTime()

    @Volatile var fps: Int = 0
        private set

    fun frame() {
        frameCount++
        val now     = System.nanoTime()
        val elapsed = now - lastTime
        if (elapsed >= 1_000_000_000L) {       // every second
            fps        = frameCount
            frameCount = 0
            lastTime   = now
        }
    }
}
