package com.tris.autest.game

/**
 * All game-balance constants.
 * Mutable at runtime so modules can override them (SpeedHack, NoCooldown, etc.).
 */
object GameConfig {

    // --- player ---
    const val DEFAULT_SPEED: Float          = 240f   // world-units / second
    const val DEFAULT_VISION_RADIUS: Float  = 320f   // world-units
    const val PLAYER_RADIUS: Float          = 18f    // collision + render radius

    // --- impostor ---
    const val DEFAULT_KILL_RANGE: Float     = 60f    // world-units
    const val DEFAULT_KILL_COOLDOWN_MS: Long = 25_000L
    const val DEFAULT_IMPOSTOR_COUNT: Int   = 2

    // --- tasks ---
    const val TASKS_PER_CREWMATE: Int       = 4
    const val TASK_INTERACT_RANGE: Float    = 48f

    // --- map ---
    const val MAP_WIDTH: Float              = 2400f
    const val MAP_HEIGHT: Float             = 1600f

    // --- bots ---
    const val BOT_COUNT: Int                = 9
    const val BOT_SPEED: Float              = 180f
    const val BOT_WANDER_INTERVAL_MS: Long  = 3_000L
    const val BOT_KILL_RANGE: Float         = DEFAULT_KILL_RANGE

    // --- runtime-mutable (modules change these) ---
    var activeSpeed: Float           = DEFAULT_SPEED
    var activeVisionRadius: Float    = DEFAULT_VISION_RADIUS
    var activeKillCooldownMs: Long   = DEFAULT_KILL_COOLDOWN_MS
    var alwaysImpostorEnabled: Boolean = false
    var noKillCooldown: Boolean      = false
    var freecamEnabled: Boolean      = false

    fun reset() {
        activeSpeed           = DEFAULT_SPEED
        activeVisionRadius    = DEFAULT_VISION_RADIUS
        activeKillCooldownMs  = DEFAULT_KILL_COOLDOWN_MS
        alwaysImpostorEnabled = false
        noKillCooldown        = false
        freecamEnabled        = false
    }
}
