# Keep all game + module classes readable in stack traces
-keepnames class com.tris.autest.**
-keepattributes SourceFile,LineNumberTable

# Gson / data classes
-keepclassmembers class com.tris.autest.** {
    <fields>;
}
-keep class com.google.gson.** { *; }

# Android component classes (service, activity)
-keep public class * extends android.app.Service
-keep public class * extends android.app.Activity
